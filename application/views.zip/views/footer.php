<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Dammtour Sigetur
    </div>
    <!-- Default to the left -->
    <strong>Template from Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved. 
  </footer>